package com.example.gcashtracker

import android.content.Context

object PaymentProcessor {
    /** Called by the SMS receiver and the notification listener with the raw message text. */
    fun handle(context: Context, text: String, source: String) {
        val payment = GcashParser.parse(text, source) ?: return
        if (!PaymentStore.add(context, payment)) return
        if (AppSettings.voiceEnabled(context)) {
            Speaker.speak(context, payment.spoken())
        }
    }
}

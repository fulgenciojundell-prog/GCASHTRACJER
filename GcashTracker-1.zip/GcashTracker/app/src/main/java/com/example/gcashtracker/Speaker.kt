package com.example.gcashtracker

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

object Speaker {
    private var tts: TextToSpeech? = null
    private var ready = false
    private var pending: String? = null

    @Synchronized
    fun speak(context: Context, text: String) {
        if (ready) {
            tts?.speak(text, TextToSpeech.QUEUE_ADD, null, "gcash")
            return
        }
        pending = text
        if (tts == null) {
            tts = TextToSpeech(context.applicationContext) { status ->
                synchronized(this@Speaker) {
                    if (status == TextToSpeech.SUCCESS) {
                        tts?.language = Locale.US
                        ready = true
                        pending?.let { tts?.speak(it, TextToSpeech.QUEUE_ADD, null, "gcash") }
                        pending = null
                    } else {
                        tts = null
                    }
                }
            }
        }
    }
}

package com.example.gcashtracker

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony

class SmsReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        val sender = messages.firstOrNull()?.originatingAddress ?: return
        if (!sender.contains("gcash", ignoreCase = true) && sender != "2882") return
        val body = messages.joinToString("") { it.messageBody ?: "" }
        PaymentProcessor.handle(context, body, "sms")
    }
}

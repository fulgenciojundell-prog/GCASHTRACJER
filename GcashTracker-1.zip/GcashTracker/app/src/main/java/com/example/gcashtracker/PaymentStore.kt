package com.example.gcashtracker

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import kotlin.math.abs

object PaymentStore {
    private const val PREFS = "payments"
    private const val KEY = "list"
    private const val DUPLICATE_WINDOW_MS = 30_000L

    private val _payments = MutableStateFlow<List<Payment>>(emptyList())
    val payments: StateFlow<List<Payment>> = _payments
    private var loaded = false

    @Synchronized
    fun load(context: Context) {
        if (loaded) return
        val raw = context.applicationContext
            .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY, null)
        if (raw != null) {
            val arr = JSONArray(raw)
            _payments.value = (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Payment(
                    id = o.getString("id"),
                    amount = o.getDouble("amount"),
                    sender = o.getString("sender"),
                    ref = if (o.isNull("ref")) null else o.getString("ref"),
                    timeMillis = o.getLong("time"),
                    source = o.getString("source"),
                )
            }
        }
        loaded = true
    }

    /** Adds the payment. Returns false if it was a duplicate (same SMS + notification). */
    @Synchronized
    fun add(context: Context, p: Payment): Boolean {
        load(context)
        val current = _payments.value
        val duplicate = current.any {
            if (p.ref != null && it.ref != null) {
                it.ref == p.ref
            } else {
                it.amount == p.amount && it.sender == p.sender &&
                    abs(it.timeMillis - p.timeMillis) < DUPLICATE_WINDOW_MS
            }
        }
        if (duplicate) return false
        val updated = (listOf(p) + current).take(500)
        _payments.value = updated
        save(context, updated)
        return true
    }

    @Synchronized
    fun clear(context: Context) {
        load(context)
        _payments.value = emptyList()
        save(context, emptyList())
    }

    fun todayTotal(list: List<Payment>): Double {
        val today = LocalDate.now()
        return list.filter {
            Instant.ofEpochMilli(it.timeMillis).atZone(ZoneId.systemDefault()).toLocalDate() == today
        }.sumOf { it.amount }
    }

    private fun save(context: Context, list: List<Payment>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id)
                    .put("amount", it.amount)
                    .put("sender", it.sender)
                    .put("ref", it.ref ?: JSONObject.NULL)
                    .put("time", it.timeMillis)
                    .put("source", it.source)
            )
        }
        context.applicationContext
            .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, arr.toString()).apply()
    }
}

object AppSettings {
    private const val PREFS = "settings"
    private const val VOICE = "voice"

    fun voiceEnabled(context: Context): Boolean =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean(VOICE, true)

    fun setVoiceEnabled(context: Context, enabled: Boolean) {
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(VOICE, enabled).apply()
    }
}

package com.example.gcashtracker

import java.util.UUID

data class Payment(
    val id: String,
    val amount: Double,
    val sender: String,
    val ref: String?,
    val timeMillis: Long,
    val source: String,
) {
    /** Text for the voice announcement, e.g. "Received 500 pesos from Juan". */
    fun spoken(): String {
        val whole = amount.toLong()
        val centavos = Math.round((amount - whole) * 100).toInt()
        val money = if (centavos == 0) "$whole pesos" else "$whole pesos and $centavos centavos"
        val name = if (sender == "Unknown") "" else " from $sender"
        return "Received $money$name"
    }
}

object GcashParser {
    // "You have received PHP 500.00 of GCash from JUAN DELA CRUZ w/ MSG: ... Ref. No. 1234567890"
    private val amountRegex =
        Regex("""received\s+(?:PHP|₱)\s*([\d,]+(?:\.\d{1,2})?)""", RegexOption.IGNORE_CASE)
    private val senderRegex =
        Regex("""\bfrom\s+(.+?)(?=\s+w/|\s+with\s+MSG|\.?\s+Your\s|\.?\s+Ref|\.?\s+Thank|$)""", RegexOption.IGNORE_CASE)
    private val refRegex =
        Regex("""Ref\.?\s*No\.?\s*:?\s*(\d+)""", RegexOption.IGNORE_CASE)

    /** Returns a Payment if [text] is a GCash "you received money" message, otherwise null. */
    fun parse(text: String, source: String, now: Long = System.currentTimeMillis()): Payment? {
        val flat = text.replace('\n', ' ').replace(Regex("\\s+"), " ").trim()
        val amount = amountRegex.find(flat)
            ?.groupValues?.get(1)
            ?.replace(",", "")
            ?.toDoubleOrNull()
            ?: return null
        val sender = senderRegex.find(flat)?.groupValues?.get(1)?.trim()
            ?.takeIf { it.isNotEmpty() } ?: "Unknown"
        val ref = refRegex.find(flat)?.groupValues?.get(1)
        return Payment(UUID.randomUUID().toString(), amount, sender, ref, now, source)
    }
}

package com.example.gcashtracker

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private var resumeTick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PaymentStore.load(this)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) { HomeScreen(resumeTick) }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        resumeTick++
    }
}

private fun peso(amount: Double) = String.format(Locale.US, "₱%,.2f", amount)

@Composable
private fun HomeScreen(tick: Int) {
    val context = LocalContext.current
    val payments by PaymentStore.payments.collectAsState()
    var voice by remember { mutableStateOf(AppSettings.voiceEnabled(context)) }

    val notificationAccess = remember(tick) {
        NotificationManagerCompat.getEnabledListenerPackages(context).contains(context.packageName)
    }
    var smsAllowed by remember(tick) {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECEIVE_SMS) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    val smsLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { smsAllowed = it }

    LazyColumn(
        modifier = Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp)) {
                    Text("Received today", style = MaterialTheme.typography.labelLarge)
                    Text(
                        peso(PaymentStore.todayTotal(payments)),
                        fontSize = 40.sp,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }
        }

        item {
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text("Announce by voice")
                Switch(checked = voice, onCheckedChange = {
                    voice = it
                    AppSettings.setVoiceEnabled(context, it)
                })
            }
        }

        if (!notificationAccess) {
            item {
                Button(
                    onClick = {
                        context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                    },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Allow notification access") }
            }
        }
        if (!smsAllowed) {
            item {
                Button(
                    onClick = { smsLauncher.launch(Manifest.permission.RECEIVE_SMS) },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Allow SMS access") }
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    PaymentProcessor.handle(
                        context,
                        "You have received PHP 500.00 of GCash from JUAN DELA CRUZ. " +
                            "Your new balance is PHP 1,500.00. Ref. No. ${System.nanoTime()}",
                        "test",
                    )
                }) { Text("Send test") }
                OutlinedButton(onClick = { PaymentStore.clear(context) }) { Text("Clear history") }
            }
        }

        item { Text("History", style = MaterialTheme.typography.titleMedium) }

        if (payments.isEmpty()) {
            item { Text("No payments yet. Tap \"Send test\" to try it.") }
        }
        items(payments, key = { it.id }) { PaymentRow(it) }
    }
}

@Composable
private fun PaymentRow(p: Payment) {
    val time = remember(p.timeMillis) {
        SimpleDateFormat("MMM d, h:mm a", Locale.getDefault()).format(Date(p.timeMillis))
    }
    Card(Modifier.fillMaxWidth()) {
        Row(
            Modifier.padding(16.dp).fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(p.sender, fontWeight = FontWeight.Medium)
                Text("$time · ${p.source}", style = MaterialTheme.typography.bodySmall)
            }
            Text(peso(p.amount), fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
    }
}

# GCash Tracker (Android)

Reads GCash "you received money" SMS and notifications on your phone, adds up what you received today, keeps a history, and can announce each payment by voice ("Received 500 pesos from Juan").

Everything stays on your phone. The app has no internet permission.

## Build and install

1. Install Android Studio and open the `GcashTracker` folder.
2. Let Gradle sync (it downloads the Android SDK parts it needs).
3. Plug in your Android phone with USB debugging on, then press Run.

## First-time setup on the phone

1. Open the app and tap **Allow notification access**, then switch on GCash Tracker.
   - If the switch is greyed out (Android 13+ for apps installed outside the Play Store): Settings > Apps > GCash Tracker > top-right menu > **Allow restricted settings**, then try again.
2. Tap **Allow SMS access** and accept.
3. Tap **Send test**. You should see ₱500.00 and hear it announced.
4. Turn off battery optimization for the app (Settings > Apps > GCash Tracker > Battery > Unrestricted), or Android may stop it in the background.

## How it works

- `GcashNotificationListener` watches notifications from the GCash app (`com.globe.gcash.android`).
- `SmsReceiver` watches SMS from GCash.
- `GcashParser` pulls the amount, sender and reference number out of the text.
- `PaymentStore` saves payments and drops duplicates (the same payment often arrives as both an SMS and a notification).

## If a payment is not detected

GCash changes its message wording now and then. Edit the regexes at the top of `GcashParser.kt`. Send me the exact text of a missed message (hide your balance and name if you like) and I will fix the pattern.
